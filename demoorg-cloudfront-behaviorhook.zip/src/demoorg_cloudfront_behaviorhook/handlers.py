import logging
from typing import Any, MutableMapping, Optional

from cloudformation_cli_python_lib import (
    BaseHookHandlerRequest,
    HandlerErrorCode,
    Hook,
    HookInvocationPoint,
    OperationStatus,
    ProgressEvent,
    SessionProxy,
    exceptions,
)

from .models import HookHandlerRequest, TypeConfigurationModel

# Use this logger to forward log messages to CloudWatch Logs.
LOG = logging.getLogger(__name__)
TYPE_NAME = "DemoOrg::CloudFront::BehaviorHook"

LOG.debug("I Starting........")
print("hello, i start")

hook = Hook(TYPE_NAME, TypeConfigurationModel)
test_entrypoint = hook.test_entrypoint


def _check_viewer_request(lambda_function_associations, lambda_arn):
    print("checking function associations")
    viewer_request_function = list(filter(lambda function: function['EventType'] == 'viewer-request', lambda_function_associations))
    if viewer_request_function:
        print("viewer-request found")
        print(viewer_request_function)
        print(viewer_request_function[0]["LambdaFunctionARN"])
        if viewer_request_function[0]["LambdaFunctionARN"] == lambda_arn:
            return True
        else:
            return False
    else:
        LOG.debug("DEBUG viewer request function not found or invalid ")
        return False


def _validate_behavior_viewer_request_lambda_arn(progress, target_name, resource_properties, ssm_key, session):
    LOG.debug("In the function - validate_behavior_viewer_request_lambda_arn")
    try:
        # # Get the expected ARN from SSM Parameter Store
        # client = session.client('ssm')
        # expected_arn_ssm = client.get_parameter(
        #     Name=ssm_key,
        #     WithDecryption=True
        # )
        # expected_arn = expected_arn_ssm.get("Parameter", {}).get("Value")

        print(ssm_key)
        expected_arn = "arn:aws:lambda:us-east-1:123456789012:function:functionName:1"

        if resource_properties:
            if resource_properties["DistributionConfig"]["DefaultCacheBehavior"]:
                if resource_properties["DistributionConfig"]["DefaultCacheBehavior"]["LambdaFunctionAssociations"]:
                    if _check_viewer_request(resource_properties["DistributionConfig"]["DefaultCacheBehavior"]["LambdaFunctionAssociations"], expected_arn):
                        print("Default Behavior: Valid Viewer Request Function Found")
                    else:
                        progress.status = OperationStatus.FAILED
                        progress.message = f"Default Behavior: No Valid Viewer Request Function Found"
                        progress.errorCode = HandlerErrorCode.NonCompliant
                        print("error: Default Behavior no Valid Viewer Request Function Found")
                else:
                    progress.status = OperationStatus.FAILED
                    progress.message = f"No Lambda Functions associated with Default Cache"
                    progress.errorCode = HandlerErrorCode.NonCompliant
                    print("error: no default cache behaviour")

                # Set
                LOG.debug(f"DEBUG Details of resource_properties: {resource_properties}")
                print(f"DEBUG Details of resource_properties: {resource_properties}")
                progress.status = OperationStatus.SUCCESS
                progress.message = f"Successfully invoked HookHandler for target {target_name} "
                print(f"Successfully invoked HookHandler for target {target_name}")
            else:
                progress.status = OperationStatus.FAILED
                progress.message = f"No Default Cache Behavior Found"
                progress.errorCode = HandlerErrorCode.NotFound
                print("error: no default cache behaviour")

            if resource_properties["DistributionConfig"]["CacheBehaviors"]:
                print("cache behaviors found")
                # print(resource_properties["DistributionConfig"]["CacheBehaviors"])
                for cacheBehavior in resource_properties["DistributionConfig"]["CacheBehaviors"]:
                    print("cache behavior found")
                    print(cacheBehavior["CachePolicyId"])
                    if _check_viewer_request(cacheBehavior["LambdaFunctionAssociations"], expected_arn):
                        print("Cache Behavior: Valid Viewer Request Function Found")
                    else:
                        progress.status = OperationStatus.FAILED
                        progress.message = f"Cache Behavior: No Valid Viewer Request Function Found"
                        progress.errorCode = HandlerErrorCode.NonCompliant
                        print("error: Cache Behavior no Valid Viewer Request Function Found")
            else:
                LOG.debug(f"DEBUG no cache behaviors found")
                print("info: no cache behaviors found")

        else:
            progress.status = OperationStatus.FAILED
            progress.message = f"Failed to verify ARN for target {target_name}."
            progress.errorCode = HandlerErrorCode.InternalFailure

    except TypeError as e:
        progress.status = OperationStatus.FAILED
        progress.message = f"was not expecting type {e}."
        progress.errorCode = HandlerErrorCode.InternalFailure

    LOG.info(f"Results Message: {progress.message}")

    print(f"about to return ")
    print(f"return details: {progress.message}, {progress.status}, {progress.errorCode} ")
    return progress


@hook.handler(HookInvocationPoint.CREATE_PRE_PROVISION)
@hook.handler(HookInvocationPoint.UPDATE_PRE_PROVISION)
def pre_create_handler(
        session: Optional[SessionProxy],
        request: HookHandlerRequest,
        callback_context: MutableMapping[str, Any],
        type_configuration: TypeConfigurationModel
) -> ProgressEvent:
    target_model = request.hookContext.targetModel
    target_name = request.hookContext.targetName
    progress: ProgressEvent = ProgressEvent(
        status=OperationStatus.IN_PROGRESS
    )
    # # Make sure this hook is running against the expected resource type
    if "AWS::CloudFront::Distribution" == target_name:
        LOG.info(f"Successfully invoked PreCreateHookHandler for target {target_name}")
        LOG.debug(f"DEBUG SSM Parameter Store Key location for compliant ARN: {type_configuration.SsmKey}")
        return _validate_behavior_viewer_request_lambda_arn(progress, target_name, request.hookContext.targetModel.get("resourceProperties"), type_configuration.SsmKey, session)
    else:
        return ProgressEvent.failed(HandlerErrorCode.InternalFailure, f"Unknown target type: {target_name}")

